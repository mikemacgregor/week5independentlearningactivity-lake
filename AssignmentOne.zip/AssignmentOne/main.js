//add an event handler to capture value of input and create new html
//element with chaeckbox, the text and button to delete

let button = document.getElementById('button');
// console.log(button);
// button.addEventListener('click', addToList);
button.onclick = addToList;

let ul = document.getElementById('toDoList');
let item = document.getElementById('toDo').value;
console.log(item);

//function to add items to the to do list
function addToList(e) {
  e.preventDefault();
  let li = document.createElement('li');
  let checkBox = document.createElement('input');
  checkBox.setAttribute("type", "checkbox");
  ul.appendChild(li);
  li.appendChild(item);
  item.appendChild(checkBox);

  }
